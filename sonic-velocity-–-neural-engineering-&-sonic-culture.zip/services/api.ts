
import { CreateJobResponse, JobStatusResponse, PresetType, MixingSettings, StemSettings, RemixSettings } from '../types';

const API_BASE_URL = 'http://localhost:8080/api';
const AUTH_TOKEN = 'supersecrettokofile'; // In real app, from env

// Helper for headers
const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${AUTH_TOKEN}`
});

// --- REAL API CALLS ---

export const generateTrackAPI = async (
  preset: PresetType,
  topic: string,
  mood: string,
  duration: number,
  lyrics?: string,
  voiceModel?: string,
  mixingSettings?: MixingSettings,
  stemSettings?: StemSettings,
  remixSettings?: RemixSettings
): Promise<CreateJobResponse> => {
  const res = await fetch(`${API_BASE_URL}/generate`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ 
      preset, 
      topic, 
      mood, 
      duration, 
      lyrics, 
      voiceModel,
      mixingSettings,
      stemSettings,
      remixSettings,
      keywords: [preset, 'tiktok', 'viral'] 
    }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Gagal request generate');
  }
  return res.json();
};

export const checkJobStatusAPI = async (jobId: string): Promise<JobStatusResponse> => {
  const res = await fetch(`${API_BASE_URL}/status/${jobId}`, {
    headers: getHeaders(),
  });
  
  if (!res.ok) {
    throw new Error('Gagal cek status');
  }
  return res.json();
};

// --- SIMULATION MODE (For Frontend Preview without Backend) ---

export const generateTrackMock = async (
  preset: PresetType,
  topic: string,
  mood: string,
  duration: number,
  lyrics?: string,
  voiceModel?: string,
  mixingSettings?: MixingSettings,
  stemSettings?: StemSettings,
  remixSettings?: RemixSettings
): Promise<CreateJobResponse> => {
  await new Promise(resolve => setTimeout(resolve, 800)); // Network delay
  return {
    jobId: `mock-${Date.now()}`,
    status: 'queued'
  };
};

export const checkJobStatusMock = async (jobId: string, secondsElapsed: number): Promise<JobStatusResponse> => {
  // Simulate processing time
  if (secondsElapsed < 5) {
    return { 
      status: 'queued',
      progress: Math.floor((secondsElapsed / 5) * 20)
    };
  } else if (secondsElapsed < 15) {
    const p = 20 + Math.floor(((secondsElapsed - 5) / 10) * 75);
    return { 
      status: 'processing',
      progress: p
    };
  } else {
    return { 
      status: 'done', 
      progress: 100,
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', // Free sample mp3
      trackId: `track-${jobId}`
    };
  }
};

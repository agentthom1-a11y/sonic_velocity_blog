
import React, { useState, useEffect } from 'react';
import { ArrowRight, Disc, Sliders, Activity, Mic, Settings, Layers, Repeat, Lock, ChevronRight, Zap, CheckCircle2, FileText, Volume2, BarChart3, Cpu, Upload, Music, RotateCw, Check, X, Sparkles, Waves, Wrench, FolderOpen, ChevronDown } from 'lucide-react';
import { PRESETS, PresetType, UserTier, MixingSettings, StemSettings, RemixSettings, Project } from '../types';
import { Visualizer } from './Visualizer';

interface GeneratorFormProps {
  onSubmit: (
    preset: PresetType, 
    topic: string, 
    mood: string, 
    lyrics?: string, 
    voiceModel?: string,
    mixingSettings?: MixingSettings,
    stemSettings?: StemSettings,
    remixSettings?: RemixSettings
  ) => void;
  isSubmitting: boolean;
  onUpgrade?: () => void;
  userTier: UserTier;
  projects?: Project[];
}

const GeneratorForm: React.FC<GeneratorFormProps> = ({ onSubmit, isSubmitting, onUpgrade, userTier, projects = [] }) => {
  // Current Project State
  const [currentProjectId, setCurrentProjectId] = useState<string>('new');
  
  const [selectedPreset, setSelectedPreset] = useState<PresetType>('koplo');
  const [topic, setTopic] = useState('');
  const [mood, setMood] = useState('');
  
  // Lyrics State
  const [lyricsText, setLyricsText] = useState('');
  const [voiceModel, setVoiceModel] = useState('Siti_Koplo_V4');

  // Mixing State (For Advanced Module)
  const [mixingSettings, setMixingSettings] = useState<MixingSettings>({
    bass: 0,
    mid: 0,
    treble: 0,
    compression: true,
    stereoWidth: 80,
    reverb: 25,
    delay: 10,
    distortion: 0
  });

  // Stem Separation State (For Cover Module)
  const [stemSettings, setStemSettings] = useState<StemSettings>({
    model: 'demucs-4stems',
    artifacts: {
        vocals: true,
        drums: true,
        bass: true,
        other: true
    }
  });

  // Remix State
  const [remixSettings, setRemixSettings] = useState<RemixSettings>({
    targetBpm: 140,
    mixStyle: 'seamless',
    autoKeyDetect: true,
    referenceTrack: undefined
  });
  
  // Remix UI State
  const [remixFile, setRemixFile] = useState<string | null>(null);
  const [isAnalyzingRemix, setIsAnalyzingRemix] = useState(false);

  // State for unlocked active modules
  const [activeModules, setActiveModules] = useState<{[key: string]: boolean}>({
    lyrics: false,
    advanced: false,
    cover: false,
    remix: false
  });

  // --- PROJECT HYDRATION LOGIC ---
  const handleProjectChange = (projectId: string) => {
      setCurrentProjectId(projectId);
      
      if (projectId === 'new') {
          // Reset to defaults
          setSelectedPreset('koplo');
          setTopic('');
          setMood('');
          setLyricsText('');
          setActiveModules({ lyrics: false, advanced: false, cover: false, remix: false });
          setMixingSettings({ bass: 0, mid: 0, treble: 0, compression: true, stereoWidth: 80, reverb: 25, delay: 10, distortion: 0 });
          setStemSettings({ model: 'demucs-4stems', artifacts: { vocals: true, drums: true, bass: true, other: true } });
          setRemixSettings({ targetBpm: 140, mixStyle: 'seamless', autoKeyDetect: true, referenceTrack: undefined });
          setRemixFile(null);
      } else {
          const project = projects.find(p => p.id === projectId);
          if (project) {
              const d = project.data;
              setSelectedPreset(d.preset);
              setTopic(d.topic);
              setMood(d.mood);
              setLyricsText(d.lyrics || '');
              if (d.voiceModel) setVoiceModel(d.voiceModel);
              if (d.mixingSettings) setMixingSettings(d.mixingSettings);
              if (d.stemSettings) setStemSettings(d.stemSettings);
              if (d.remixSettings) setRemixSettings(d.remixSettings);
              if (d.activeModules) setActiveModules(d.activeModules);
              // If remix active, assume synced
              if (d.activeModules.remix) setRemixFile("Restored_Session.mp3");
          }
      }
  };

  const toggleModule = (id: string) => {
    setActiveModules(prev => ({...prev, [id]: !prev[id]}));
  };

  const handleRemixUpload = () => {
     if (remixFile) return; // Already uploaded
     setIsAnalyzingRemix(true);
     // Simulate analysis
     setTimeout(() => {
         const mockFile = "DJ_OPUS_VIRAL_V2.mp3";
         setRemixFile(mockFile);
         setRemixSettings(prev => ({
             ...prev, 
             referenceTrack: mockFile,
             targetBpm: 145 // Auto-detected BPM
         }));
         setIsAnalyzingRemix(false);
     }, 2000);
  };

  const clearRemixFile = (e: React.MouseEvent) => {
      e.stopPropagation();
      setRemixFile(null);
      setRemixSettings(prev => ({...prev, referenceTrack: undefined}));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic) return;
    
    // Pass lyrics if the module is active
    const lyricsPayload = activeModules.lyrics ? lyricsText : undefined;
    const voicePayload = activeModules.lyrics ? voiceModel : undefined;
    
    // Pass mixing settings if the module is active
    const mixingPayload = activeModules.advanced ? mixingSettings : undefined;
    
    // Pass stem settings if the module is active
    const stemPayload = activeModules.cover ? stemSettings : undefined;

    // Pass remix settings if the module is active
    const remixPayload = activeModules.remix ? remixSettings : undefined;

    onSubmit(selectedPreset, topic, mood || 'Viral, Upbeat, Bass-heavy', lyricsPayload, voicePayload, mixingPayload, stemPayload, remixPayload);
  };

  // Check if module is unlocked for current tier
  const isUnlocked = (moduleId: string) => {
    // ALWAYS LOCK REMIX FOR DEVELOPMENT
    if (moduleId === 'remix') return false;

    if (userTier === 'free') return false;
    if (userTier === 'pro' || userTier === 'agency') return true;
    
    // Premium Logic
    if (userTier === 'premium') {
        // Unlock Lyrics, Cover (Stems)
        if (moduleId === 'lyrics' || moduleId === 'cover') return true;
        return false;
    }
    return false;
  };

  const renderPhantomUI = (id: string) => {
    switch(id) {
      case 'lyrics':
        return (
          <div className="flex items-end gap-0.5 h-6 w-full mt-3 opacity-30">
             {[...Array(16)].map((_, i) => (
                <div key={i} className="w-1 bg-white rounded-t-[1px]" style={{height: `${20 + Math.random() * 80}%`}}></div>
             ))}
          </div>
        );
      case 'advanced':
         return (
          <div className="flex justify-between items-center h-8 w-full mt-2 px-1 opacity-30">
             {[...Array(5)].map((_, i) => (
                <div key={i} className="w-[1px] h-full bg-white/50 relative">
                    <div className="absolute w-1.5 h-0.5 bg-white -left-[2px]" style={{top: `${20 + Math.random() * 60}%`}}></div>
                </div>
             ))}
          </div>
         );
      case 'cover':
         return (
          <div className="flex flex-col gap-1 w-full mt-3 opacity-30">
             <div className="h-1 w-full bg-white/50 rounded-sm"></div>
             <div className="h-1 w-[70%] bg-white/30 rounded-sm"></div>
             <div className="h-1 w-[50%] bg-white/40 rounded-sm"></div>
             <div className="h-1 w-[85%] bg-white/20 rounded-sm"></div>
          </div>
         );
      case 'remix':
         return (
          <div className="flex justify-start w-full mt-2 opacity-30 pl-1">
              <div className="w-8 h-8 rounded-full border border-white relative rotate-45">
                 <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-2 bg-white"></div>
              </div>
          </div>
         );
      default: return null;
    }
  }

  return (
    <div className="w-full">
      <form onSubmit={handleSubmit} className="space-y-10">
        
        {/* NEW: PROJECT SELECTOR (Only for logged in users) */}
        {userTier !== 'free' && (
            <div className="border border-green-900/30 bg-green-950/5 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <FolderOpen className="w-4 h-4 text-green-500" />
                    <label className="text-[10px] font-mono text-green-400 uppercase tracking-widest">Session Loader</label>
                </div>
                <div className="relative group w-64">
                     <select 
                        value={currentProjectId}
                        onChange={(e) => handleProjectChange(e.target.value)}
                        className="w-full bg-black border border-green-900/50 text-white text-xs font-mono px-4 py-2 appearance-none focus:outline-none focus:border-green-500 uppercase cursor-pointer hover:bg-neutral-900"
                     >
                         <option value="new">Initialize New Session...</option>
                         <optgroup label="Saved Projects">
                             {projects.map(p => (
                                 <option key={p.id} value={p.id}>{p.name}</option>
                             ))}
                         </optgroup>
                     </select>
                     <ChevronDown className="absolute right-3 top-2.5 w-3 h-3 text-neutral-500 pointer-events-none" />
                </div>
            </div>
        )}

        {/* NEW: System Modules (PHANTOM UI + OVERLAY) */}
        <div className="space-y-4 relative">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
             <label className="font-mono text-xs text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                {userTier === 'free' ? <Lock className="w-3 h-3 text-neutral-600" /> : <Settings className="w-3 h-3 text-green-500" />}
                00 // Advanced Modules ({userTier === 'free' ? 'Pro' : userTier})
             </label>
             {userTier === 'free' ? (
                <span className="text-[9px] font-mono text-red-900 bg-red-950/30 border border-red-900/50 px-1.5 py-0.5 rounded-sm uppercase">Restricted</span>
             ) : (
                <span className="text-[9px] font-mono text-green-500 bg-green-900/20 border border-green-900/50 px-1.5 py-0.5 rounded-sm uppercase">Unlocked</span>
             )}
          </div>
          
          {/* The Grid of Locked/Unlocked Features */}
          <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 ${userTier === 'free' ? 'opacity-50 pointer-events-none filter grayscale' : ''}`}>
             {[
                { id: 'lyrics', label: 'Lyrics Engine', icon: Mic, subtitle: "Vocal Synthesis" },
                { id: 'advanced', label: 'Pro Controls', icon: Settings, subtitle: "Mixing & FX Engine" },
                { id: 'cover', label: 'Cover Mode', icon: Layers, subtitle: "Stem Separation" },
                { id: 'remix', label: 'Remix Engine', icon: Repeat, subtitle: "Auto-Beatmatch (Dev)" }
             ].map((feature) => {
                const unlocked = isUnlocked(feature.id);
                const active = activeModules[feature.id];
                // Special check for "On Development" status
                const isOnDev = feature.id === 'remix';

                return (
                <div
                  key={feature.id}
                  onClick={() => unlocked && toggleModule(feature.id)}
                  className={`relative overflow-hidden border transition-all duration-300 ${
                     unlocked 
                       ? active 
                          ? 'bg-green-950/20 border-green-500/50 cursor-pointer shadow-[0_0_15px_rgba(0,255,0,0.1)]' 
                          : 'bg-neutral-950 border-neutral-800 hover:border-neutral-600 cursor-pointer'
                       : 'bg-neutral-950 border-neutral-900 opacity-70 cursor-not-allowed'
                  }`}
                >
                  {/* Striped Background for locked */}
                  {!unlocked && (
                      <div className="absolute inset-0 opacity-5 bg-[repeating-linear-gradient(45deg,transparent,transparent_5px,#fff_5px,#fff_6px)]"></div>
                  )}
                  
                  {/* Status Dot for Unlocked */}
                  {unlocked && (
                      <div className={`absolute top-2 right-2 w-1.5 h-1.5 rounded-full ${active ? 'bg-green-500 shadow-[0_0_5px_#0f0]' : 'bg-neutral-800'}`}></div>
                  )}

                  {/* Lock Icon for Locked items in non-free mode OR Dev items */}
                  {!unlocked && userTier !== 'free' && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-[1px] flex flex-col items-center justify-center z-20 text-center px-2">
                          {isOnDev ? <Wrench className="w-4 h-4 text-yellow-500 mb-1" /> : <Lock className="w-4 h-4 text-neutral-500 mb-1" />}
                          <span className={`text-[8px] font-mono uppercase ${isOnDev ? 'text-yellow-500' : 'text-neutral-500'}`}>
                            {isOnDev ? 'On Development' : 'Locked'}
                          </span>
                      </div>
                  )}
                  
                  <div className="p-4 relative z-10 flex flex-col h-32 justify-between">
                      <div className="flex justify-between items-start">
                          <feature.icon className={`w-4 h-4 ${active ? 'text-green-400' : 'text-neutral-400'}`} />
                      </div>
                      
                      {/* Phantom UI Render */}
                      <div className="flex-1 flex items-center">
                        {renderPhantomUI(feature.id)}
                      </div>

                      <div>
                          <div className={`text-[10px] font-bold uppercase tracking-widest ${active ? 'text-green-400' : 'text-neutral-400'}`}>{feature.label}</div>
                          <div className="text-[8px] font-mono uppercase text-neutral-600 mt-1">{feature.subtitle}</div>
                      </div>
                  </div>
                </div>
             )})}
          </div>

          {/* --- FUNCTIONAL LYRICS CONSOLE (When Lyrics Module Active) --- */}
          {isUnlocked('lyrics') && activeModules.lyrics && (
            <div className="w-full border border-green-900/30 bg-green-950/5 p-6 mt-4 animate-[slideDown_0.3s_ease-out]">
               <div className="flex items-center justify-between mb-6 border-b border-green-900/20 pb-4">
                  <div className="flex items-center gap-3">
                     <Mic className="w-4 h-4 text-green-500" />
                     <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest">Vocal Processing Unit</h3>
                  </div>
                  <div className="flex items-center gap-2">
                     <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                     <span className="text-[9px] font-mono text-green-600 uppercase">Module Online</span>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Left: Controls */}
                  <div className="space-y-4">
                     <div>
                        <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-2">Voice Model</label>
                        <select 
                           value={voiceModel} 
                           onChange={(e) => setVoiceModel(e.target.value)}
                           className="w-full bg-black border border-green-900/30 text-green-400 text-xs font-mono px-3 py-2 focus:outline-none focus:border-green-500 uppercase"
                        >
                           <option value="Siti_Koplo_V4">Siti (Koplo Soprano)</option>
                           <option value="Bambang_Bass">Bambang (MC Bass)</option>
                           <option value="Cyber_Diva_ID">Cyber Diva (Electronic)</option>
                        </select>
                     </div>
                     
                     <div>
                         <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-2">Formant Shift</label>
                         <div className="flex items-center gap-2">
                             <input type="range" min="0" max="100" defaultValue="50" className="w-full h-1 bg-green-900/30 appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-green-500 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-none" />
                         </div>
                     </div>

                     {/* Visualizer */}
                     <div className="h-16 bg-black border border-green-900/30 flex items-end justify-center gap-1 px-2 pb-1 opacity-50">
                         {[...Array(15)].map((_, i) => (
                            <div key={i} className="w-1.5 bg-green-500/50 animate-[bounce_1s_infinite]" style={{height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.1}s`}}></div>
                         ))}
                     </div>
                  </div>

                  {/* Right: Lyrics Input */}
                  <div className="md:col-span-2">
                     <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-2 flex justify-between">
                        <span>Lyrics Input Sequence</span>
                        <span className="text-green-500">{lyricsText.length}/500 Chars</span>
                     </label>
                     <div className="relative">
                        <div className="absolute left-0 top-0 bottom-0 w-6 bg-green-950/20 border-r border-green-900/10 flex flex-col items-center pt-3 gap-1 pointer-events-none">
                            {[...Array(5)].map((_, i) => (
                                <span key={i} className="text-[8px] font-mono text-green-800">{i + 1}</span>
                            ))}
                        </div>
                        <textarea 
                           value={lyricsText}
                           onChange={(e) => setLyricsText(e.target.value)}
                           placeholder="Enter your lyrics here..."
                           className="w-full h-40 bg-black border border-green-900/30 text-green-400 font-mono text-xs p-3 pl-8 focus:outline-none focus:border-green-500 resize-none placeholder-green-900"
                        />
                     </div>
                  </div>
               </div>
            </div>
          )}

          {/* --- FUNCTIONAL MIXING CONSOLE (When Advanced Module Active) --- */}
          {isUnlocked('advanced') && activeModules.advanced && (
            <div className="w-full border border-green-900/30 bg-green-950/5 p-6 mt-4 animate-[slideDown_0.3s_ease-out]">
               <div className="flex items-center justify-between mb-6 border-b border-green-900/20 pb-4">
                  <div className="flex items-center gap-3">
                     <Sliders className="w-4 h-4 text-green-500" />
                     <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest">Mixing & FX Console</h3>
                  </div>
                  <div className="flex items-center gap-2">
                     <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                     <span className="text-[9px] font-mono text-green-600 uppercase">Engine Ready</span>
                  </div>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* EQ Section */}
                  <div className="lg:col-span-1 space-y-6">
                      <h4 className="text-[10px] font-mono text-green-600/70 uppercase mb-4 border-b border-green-900/20 pb-2 w-fit">3-Band Equalizer</h4>
                      
                      <div className="space-y-5">
                          {/* Bass */}
                          <div className="grid grid-cols-6 gap-4 items-center">
                              <span className="col-span-1 text-[10px] font-mono text-green-400 uppercase">Low</span>
                              <div className="col-span-4 relative h-2 bg-black border border-green-900/30">
                                  <input 
                                      type="range" min="-12" max="12" 
                                      value={mixingSettings.bass}
                                      onChange={(e) => setMixingSettings({...mixingSettings, bass: parseInt(e.target.value)})}
                                      className="absolute inset-0 w-full h-full opacity-0 z-10 cursor-pointer"
                                  />
                                  {/* Visual Track */}
                                  <div className="absolute top-0 bottom-0 bg-green-500/20 w-px left-1/2"></div>
                                  <div 
                                      className="absolute top-0 bottom-0 bg-green-500 transition-all" 
                                      style={{
                                          left: mixingSettings.bass < 0 ? `${50 + (mixingSettings.bass/12)*50}%` : '50%',
                                          width: `${Math.abs(mixingSettings.bass/12)*50}%`
                                      }}
                                  ></div>
                                  <div 
                                      className="absolute top-0 bottom-0 w-1 bg-white"
                                      style={{ left: `${50 + (mixingSettings.bass/12)*50}%` }}
                                  ></div>
                              </div>
                              <span className="col-span-1 text-[10px] font-mono text-green-400 text-right">{mixingSettings.bass > 0 ? '+' : ''}{mixingSettings.bass}</span>
                          </div>

                          {/* Mid */}
                          <div className="grid grid-cols-6 gap-4 items-center">
                              <span className="col-span-1 text-[10px] font-mono text-green-400 uppercase">Mid</span>
                              <div className="col-span-4 relative h-2 bg-black border border-green-900/30">
                                  <input 
                                      type="range" min="-12" max="12" 
                                      value={mixingSettings.mid}
                                      onChange={(e) => setMixingSettings({...mixingSettings, mid: parseInt(e.target.value)})}
                                      className="absolute inset-0 w-full h-full opacity-0 z-10 cursor-pointer"
                                  />
                                  <div className="absolute top-0 bottom-0 bg-green-500/20 w-px left-1/2"></div>
                                  <div 
                                      className="absolute top-0 bottom-0 bg-green-500 transition-all" 
                                      style={{
                                          left: mixingSettings.mid < 0 ? `${50 + (mixingSettings.mid/12)*50}%` : '50%',
                                          width: `${Math.abs(mixingSettings.mid/12)*50}%`
                                      }}
                                  ></div>
                                  <div 
                                      className="absolute top-0 bottom-0 w-1 bg-white"
                                      style={{ left: `${50 + (mixingSettings.mid/12)*50}%` }}
                                  ></div>
                              </div>
                              <span className="col-span-1 text-[10px] font-mono text-green-400 text-right">{mixingSettings.mid > 0 ? '+' : ''}{mixingSettings.mid}</span>
                          </div>

                          {/* Treble */}
                          <div className="grid grid-cols-6 gap-4 items-center">
                              <span className="col-span-1 text-[10px] font-mono text-green-400 uppercase">High</span>
                              <div className="col-span-4 relative h-2 bg-black border border-green-900/30">
                                  <input 
                                      type="range" min="-12" max="12" 
                                      value={mixingSettings.treble}
                                      onChange={(e) => setMixingSettings({...mixingSettings, treble: parseInt(e.target.value)})}
                                      className="absolute inset-0 w-full h-full opacity-0 z-10 cursor-pointer"
                                  />
                                  <div className="absolute top-0 bottom-0 bg-green-500/20 w-px left-1/2"></div>
                                  <div 
                                      className="absolute top-0 bottom-0 bg-green-500 transition-all" 
                                      style={{
                                          left: mixingSettings.treble < 0 ? `${50 + (mixingSettings.treble/12)*50}%` : '50%',
                                          width: `${Math.abs(mixingSettings.treble/12)*50}%`
                                      }}
                                  ></div>
                                  <div 
                                      className="absolute top-0 bottom-0 w-1 bg-white"
                                      style={{ left: `${50 + (mixingSettings.treble/12)*50}%` }}
                                  ></div>
                              </div>
                              <span className="col-span-1 text-[10px] font-mono text-green-400 text-right">{mixingSettings.treble > 0 ? '+' : ''}{mixingSettings.treble}</span>
                          </div>
                      </div>
                  </div>

                  {/* Dynamics Section */}
                  <div className="space-y-6 border-l border-green-900/20 lg:pl-6">
                      <h4 className="text-[10px] font-mono text-green-600/70 uppercase mb-4 border-b border-green-900/20 pb-2 w-fit">Dynamics & Spatial</h4>
                      
                      {/* Compressor Toggle */}
                      <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                              <Activity className="w-4 h-4 text-green-500" />
                              <span className="text-[10px] font-mono text-green-400 uppercase">Master Comp</span>
                          </div>
                          <button 
                              type="button"
                              onClick={() => setMixingSettings(prev => ({...prev, compression: !prev.compression}))}
                              className={`w-10 h-5 rounded-full border transition-colors relative ${mixingSettings.compression ? 'bg-green-900/50 border-green-500' : 'bg-black border-neutral-700'}`}
                          >
                              <div className={`absolute top-0.5 w-3.5 h-3.5 rounded-full transition-all ${mixingSettings.compression ? 'bg-green-500 left-5 shadow-[0_0_5px_#0f0]' : 'bg-neutral-500 left-0.5'}`}></div>
                          </button>
                      </div>

                      {/* Stereo Width */}
                      <div>
                           <div className="flex justify-between mb-2">
                              <span className="text-[10px] font-mono text-green-400 uppercase">Stereo Width</span>
                              <span className="text-[10px] font-mono text-green-400">{mixingSettings.stereoWidth}%</span>
                           </div>
                           <input 
                              type="range" min="0" max="100" 
                              value={mixingSettings.stereoWidth}
                              onChange={(e) => setMixingSettings({...mixingSettings, stereoWidth: parseInt(e.target.value)})}
                              className="w-full h-1 bg-green-900/30 appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-green-500 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-none" 
                           />
                      </div>
                      
                      {/* Visualizer Mini */}
                      <div className="mt-4 h-24 bg-black border border-green-900/30 p-2 relative overflow-hidden flex items-center justify-center">
                           <div className={`absolute w-16 h-16 rounded-full border border-green-500/30 animate-[ping_2s_infinite]`} style={{ opacity: mixingSettings.compression ? 0.6 : 0.1 }}></div>
                           <div className="flex gap-1 h-full items-end opacity-60">
                               {[...Array(8)].map((_,i) => (
                                   <div key={i} className="w-2 bg-green-500 transition-all" style={{ height: `${30 + Math.random() * 50}%` }}></div>
                               ))}
                           </div>
                      </div>

                  </div>

                  {/* NEW: Effect Engine */}
                  <div className="space-y-6 border-l border-green-900/20 lg:pl-6">
                     <div className="flex items-center justify-between border-b border-green-900/20 pb-2 mb-4">
                        <h4 className="text-[10px] font-mono text-green-600/70 uppercase flex items-center gap-2">
                            <Sparkles className="w-3 h-3" /> Effect Engine
                        </h4>
                        <div className="flex items-center gap-1">
                           <span className={`w-1.5 h-1.5 rounded-full ${mixingSettings.reverb > 0 || mixingSettings.delay > 0 || mixingSettings.distortion > 0 ? 'bg-green-500 shadow-[0_0_5px_#0f0]' : 'bg-neutral-700'}`}></span>
                           <span className="text-[8px] font-mono text-neutral-500 uppercase">Circuit Active</span>
                        </div>
                     </div>

                     <div className="grid grid-cols-3 gap-2">
                        {/* Reverb Knob */}
                        <div className="flex flex-col items-center group">
                            <div className="relative w-12 h-12 bg-black border border-green-900/50 rounded-full mb-2 flex items-center justify-center shadow-[inset_0_0_10px_rgba(0,255,0,0.1)] group-hover:border-green-500/80 transition-colors">
                                <div 
                                    className="absolute w-full h-full rounded-full" 
                                    style={{ transform: `rotate(${mixingSettings.reverb * 3.6}deg)` }}
                                >
                                   <div className="w-1 h-2 bg-green-500 absolute top-1 left-1/2 -translate-x-1/2 rounded-full shadow-[0_0_5px_#0f0]"></div>
                                </div>
                                <input 
                                    type="range" min="0" max="100"
                                    value={mixingSettings.reverb}
                                    onChange={(e) => setMixingSettings({...mixingSettings, reverb: parseInt(e.target.value)})}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                    title="Reverb Amount"
                                />
                                <span className="text-[9px] font-mono text-green-500">{mixingSettings.reverb}</span>
                            </div>
                            <span className="text-[8px] font-mono text-neutral-400 uppercase group-hover:text-green-400 transition-colors">Space</span>
                        </div>

                        {/* Delay Knob */}
                        <div className="flex flex-col items-center group">
                            <div className="relative w-12 h-12 bg-black border border-green-900/50 rounded-full mb-2 flex items-center justify-center shadow-[inset_0_0_10px_rgba(0,255,0,0.1)] group-hover:border-green-500/80 transition-colors">
                                <div 
                                    className="absolute w-full h-full rounded-full" 
                                    style={{ transform: `rotate(${mixingSettings.delay * 3.6}deg)` }}
                                >
                                   <div className="w-1 h-2 bg-green-500 absolute top-1 left-1/2 -translate-x-1/2 rounded-full shadow-[0_0_5px_#0f0]"></div>
                                </div>
                                <input 
                                    type="range" min="0" max="100"
                                    value={mixingSettings.delay}
                                    onChange={(e) => setMixingSettings({...mixingSettings, delay: parseInt(e.target.value)})}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                    title="Delay Amount"
                                />
                                <span className="text-[9px] font-mono text-green-500">{mixingSettings.delay}</span>
                            </div>
                            <span className="text-[8px] font-mono text-neutral-400 uppercase group-hover:text-green-400 transition-colors">Echo</span>
                        </div>

                        {/* Distortion Knob */}
                         <div className="flex flex-col items-center group">
                            <div className="relative w-12 h-12 bg-black border border-green-900/50 rounded-full mb-2 flex items-center justify-center shadow-[inset_0_0_10px_rgba(0,255,0,0.1)] group-hover:border-yellow-600/80 transition-colors">
                                <div 
                                    className="absolute w-full h-full rounded-full" 
                                    style={{ transform: `rotate(${mixingSettings.distortion * 3.6}deg)` }}
                                >
                                   <div className="w-1 h-2 bg-yellow-500 absolute top-1 left-1/2 -translate-x-1/2 rounded-full shadow-[0_0_5px_#fbbf24]"></div>
                                </div>
                                <input 
                                    type="range" min="0" max="100"
                                    value={mixingSettings.distortion}
                                    onChange={(e) => setMixingSettings({...mixingSettings, distortion: parseInt(e.target.value)})}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                    title="Drive Amount"
                                />
                                <span className={`text-[9px] font-mono ${mixingSettings.distortion > 0 ? 'text-yellow-500' : 'text-neutral-600'}`}>{mixingSettings.distortion}</span>
                            </div>
                            <span className="text-[8px] font-mono text-neutral-400 uppercase group-hover:text-yellow-500 transition-colors">Drive</span>
                        </div>
                     </div>
                     
                     {/* Signal Chain Visual */}
                     <div className="mt-2 flex items-center justify-between px-1 bg-black/40 py-2 rounded-sm border border-green-900/10">
                        <div className="flex flex-col items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                            <span className="text-[7px] font-mono text-neutral-500 uppercase">IN</span>
                        </div>
                        <div className="h-[1px] bg-green-900 flex-1 mx-1 relative overflow-hidden">
                           <div className="absolute inset-0 bg-green-500/50 animate-[slideRight_1s_linear_infinite]"></div>
                        </div>
                        <Waves className={`w-3 h-3 ${mixingSettings.reverb > 0 || mixingSettings.delay > 0 ? 'text-green-400 drop-shadow-[0_0_5px_rgba(74,222,128,0.5)]' : 'text-green-900'}`} />
                        <div className="h-[1px] bg-green-900 flex-1 mx-1 relative overflow-hidden">
                           <div className="absolute inset-0 bg-green-500/50 animate-[slideRight_1s_linear_infinite]" style={{ animationDelay: '0.5s' }}></div>
                        </div>
                        <Zap className={`w-3 h-3 ${mixingSettings.distortion > 0 ? 'text-yellow-500 drop-shadow-[0_0_5px_rgba(234,179,8,0.5)]' : 'text-neutral-800'}`} />
                        <div className="h-[1px] bg-green-900 flex-1 mx-1 relative overflow-hidden">
                           <div className="absolute inset-0 bg-green-500/50 animate-[slideRight_1s_linear_infinite]" style={{ animationDelay: '0.8s' }}></div>
                        </div>
                        <div className="flex flex-col items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                            <span className="text-[7px] font-mono text-neutral-500 uppercase">OUT</span>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
          )}

           {/* --- FUNCTIONAL COVER MODE / STEM SEPARATION (When Cover Module Active) --- */}
          {isUnlocked('cover') && activeModules.cover && (
             <div className="w-full border border-green-900/30 bg-green-950/5 p-6 mt-4 animate-[slideDown_0.3s_ease-out]">
                 <div className="flex items-center justify-between mb-6 border-b border-green-900/20 pb-4">
                    <div className="flex items-center gap-3">
                       <Layers className="w-4 h-4 text-green-500" />
                       <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest">Stem Isolation Unit</h3>
                    </div>
                    <div className="flex items-center gap-2">
                       <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                       <span className="text-[9px] font-mono text-green-600 uppercase">Demucs-v4 Online</span>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Left: Layer Selection */}
                    <div className="space-y-4">
                        <h4 className="text-[10px] font-mono text-green-600/70 uppercase mb-4">Export Artifacts</h4>
                        <div className="grid grid-cols-2 gap-3">
                           {['vocals', 'drums', 'bass', 'other'].map((stem) => (
                              <button
                                 key={stem}
                                 type="button"
                                 onClick={() => setStemSettings(prev => ({
                                    ...prev, 
                                    artifacts: { ...prev.artifacts, [stem]: !prev.artifacts[stem as keyof typeof prev.artifacts] }
                                 }))}
                                 className={`flex flex-col items-center justify-center p-4 border transition-all ${
                                    stemSettings.artifacts[stem as keyof typeof stemSettings.artifacts]
                                    ? 'bg-green-900/30 border-green-500/50 text-white'
                                    : 'bg-black border-neutral-800 text-neutral-500 hover:border-neutral-600'
                                 }`}
                              >
                                 <span className="text-[10px] font-bold uppercase tracking-widest mb-1">{stem}</span>
                                 <div className={`w-2 h-2 rounded-full ${stemSettings.artifacts[stem as keyof typeof stemSettings.artifacts] ? 'bg-green-500 shadow-[0_0_5px_#0f0]' : 'bg-neutral-800'}`}></div>
                              </button>
                           ))}
                        </div>
                    </div>

                    {/* Right: Visualization & Model Config */}
                    <div className="flex flex-col justify-between">
                        <div>
                           <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-2">Processing Model</label>
                           <div className="flex gap-2">
                               <button 
                                  type="button" 
                                  onClick={() => setStemSettings(prev => ({...prev, model: 'spleeter-2stems'}))}
                                  className={`flex-1 py-2 text-[9px] font-mono uppercase border ${stemSettings.model === 'spleeter-2stems' ? 'bg-green-900/30 border-green-500 text-green-400' : 'bg-black border-neutral-800 text-neutral-500'}`}
                               >
                                  Fast (2-Stems)
                               </button>
                               <button 
                                  type="button"
                                  onClick={() => setStemSettings(prev => ({...prev, model: 'demucs-4stems'}))}
                                  className={`flex-1 py-2 text-[9px] font-mono uppercase border ${stemSettings.model === 'demucs-4stems' ? 'bg-green-900/30 border-green-500 text-green-400' : 'bg-black border-neutral-800 text-neutral-500'}`}
                               >
                                  HQ (4-Stems)
                               </button>
                           </div>
                        </div>

                        {/* Visual Stack */}
                        <div className="mt-6 space-y-1 relative h-32 flex flex-col justify-end p-4 bg-black border border-neutral-800">
                            <div className="absolute top-2 right-2 text-[8px] font-mono text-neutral-600 uppercase">Output Stack</div>
                            
                            {stemSettings.artifacts.vocals && (
                               <div className="h-4 w-full bg-green-500/20 border-l-2 border-green-500 animate-[slideRight_0.3s_ease-out]">
                                  <div className="text-[8px] text-green-500 pl-2 pt-0.5 font-mono">VOCALS.WAV</div>
                               </div>
                            )}
                            {stemSettings.artifacts.other && (
                               <div className="h-4 w-[90%] bg-green-500/20 border-l-2 border-green-500 animate-[slideRight_0.4s_ease-out]">
                                  <div className="text-[8px] text-green-500 pl-2 pt-0.5 font-mono">SYNTH.WAV</div>
                               </div>
                            )}
                            {stemSettings.artifacts.bass && (
                               <div className="h-4 w-[95%] bg-green-500/20 border-l-2 border-green-500 animate-[slideRight_0.5s_ease-out]">
                                  <div className="text-[8px] text-green-500 pl-2 pt-0.5 font-mono">BASS.WAV</div>
                               </div>
                            )}
                            {stemSettings.artifacts.drums && (
                               <div className="h-4 w-full bg-green-500/20 border-l-2 border-green-500 animate-[slideRight_0.6s_ease-out]">
                                  <div className="text-[8px] text-green-500 pl-2 pt-0.5 font-mono">DRUMS.WAV</div>
                               </div>
                            )}
                        </div>
                    </div>
                 </div>
             </div>
          )}

          {/* --- FUNCTIONAL REMIX ENGINE / AUTO-BEATMATCH (When Remix Module Active) --- */}
          {isUnlocked('remix') && activeModules.remix && (
             <div className="w-full border border-green-900/30 bg-green-950/5 p-6 mt-4 animate-[slideDown_0.3s_ease-out]">
                 <div className="flex items-center justify-between mb-6 border-b border-green-900/20 pb-4">
                    <div className="flex items-center gap-3">
                       <Repeat className="w-4 h-4 text-green-500" />
                       <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest">Remix Logic Unit</h3>
                    </div>
                    <div className="flex items-center gap-2">
                       <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                       <span className="text-[9px] font-mono text-green-600 uppercase">Ongoing Launch // Active</span>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Left: BPM & Style */}
                    <div className="md:col-span-2 space-y-6">
                       
                       {/* BPM Control */}
                       <div>
                          <div className="flex justify-between mb-2">
                             <label className="text-[10px] font-mono text-green-600/70 uppercase">Target BPM</label>
                             <span className="text-[12px] font-bold text-green-400 font-mono">{remixSettings.targetBpm} BPM</span>
                          </div>
                          <div className="relative h-6 bg-black border border-green-900/30 rounded-sm flex items-center px-2">
                             <input 
                                type="range" min="80" max="180" 
                                value={remixSettings.targetBpm}
                                onChange={(e) => setRemixSettings({...remixSettings, targetBpm: parseInt(e.target.value)})}
                                className="w-full h-1 bg-green-900/30 appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-green-500 [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-black [&::-webkit-slider-thumb]:appearance-none" 
                             />
                          </div>
                       </div>

                       {/* Mix Style */}
                       <div>
                          <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-3">Transition Algorithm</label>
                          <div className="flex gap-2">
                             {['seamless', 'drop-swap', 'mashup'].map((style) => (
                                <button
                                   key={style}
                                   type="button"
                                   onClick={() => setRemixSettings({...remixSettings, mixStyle: style as any})}
                                   className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-wider border transition-all ${
                                      remixSettings.mixStyle === style 
                                      ? 'bg-green-900/30 border-green-500 text-white shadow-[0_0_10px_rgba(0,255,0,0.1)]' 
                                      : 'bg-black border-neutral-800 text-neutral-500 hover:border-neutral-600'
                                   }`}
                                >
                                   {style}
                                </button>
                             ))}
                          </div>
                       </div>

                       {/* Reference File Input Simulation */}
                       <div className="mt-4">
                           <label className="block text-[10px] font-mono text-green-600/70 uppercase mb-2">Reference Audio (Optional)</label>
                           
                           {!remixFile && !isAnalyzingRemix && (
                             <div 
                               onClick={handleRemixUpload}
                               className="border border-dashed border-green-900/50 bg-black/50 rounded-sm p-4 text-center hover:bg-green-950/10 transition-colors cursor-pointer group h-24 flex flex-col items-center justify-center"
                             >
                                 <Upload className="w-5 h-5 text-green-600 mx-auto mb-2 group-hover:text-green-400 transition-colors" />
                                 <p className="text-[10px] text-neutral-500 font-mono uppercase group-hover:text-green-400 transition-colors">
                                    Drag & Drop MP3/WAV for Style Match
                                 </p>
                             </div>
                           )}

                           {isAnalyzingRemix && (
                              <div className="border border-green-900/50 bg-black/50 rounded-sm p-4 h-24 flex flex-col items-center justify-center">
                                  <RotateCw className="w-5 h-5 text-green-500 animate-spin mb-2" />
                                  <p className="text-[10px] text-green-500 font-mono uppercase animate-pulse">Analyzing Waveform...</p>
                              </div>
                           )}

                           {remixFile && (
                              <div className="border border-green-500/50 bg-green-950/20 rounded-sm p-4 h-24 flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                      <div className="w-8 h-8 bg-green-900/50 flex items-center justify-center border border-green-500/50">
                                          <Music className="w-4 h-4 text-green-500" />
                                      </div>
                                      <div>
                                          <div className="text-[10px] font-bold text-white uppercase tracking-wide">{remixFile}</div>
                                          <div className="text-[9px] font-mono text-green-400 flex items-center gap-1">
                                              <CheckCircle2 className="w-3 h-3" /> Analysis Complete
                                          </div>
                                      </div>
                                  </div>
                                  <button 
                                    type="button"
                                    onClick={clearRemixFile}
                                    className="text-neutral-500 hover:text-white p-2"
                                  >
                                      <X className="w-4 h-4" />
                                  </button>
                              </div>
                           )}
                       </div>
                    </div>

                    {/* Right: Beatmatch Visualizer */}
                    <div className="flex flex-col items-center justify-center bg-black border border-neutral-800 p-6 relative overflow-hidden">
                        <button 
                           type="button"
                           onClick={() => setRemixSettings(prev => ({...prev, autoKeyDetect: !prev.autoKeyDetect}))}
                           className="absolute top-2 right-2 flex items-center gap-1 cursor-pointer hover:opacity-80"
                        >
                           <div className={`w-1.5 h-1.5 rounded-full transition-colors ${remixSettings.autoKeyDetect ? 'bg-green-500 shadow-[0_0_5px_#0f0]' : 'bg-neutral-700'}`}></div>
                           <span className={`text-[8px] font-mono uppercase ${remixSettings.autoKeyDetect ? 'text-green-500' : 'text-neutral-500'}`}>Auto-Key</span>
                        </button>
                        
                        {/* Rotating Turntable Visual */}
                        <div className={`w-32 h-32 rounded-full border-4 border-neutral-900 relative flex items-center justify-center ${remixFile || isAnalyzingRemix ? 'animate-[spin_2s_linear_infinite]' : 'animate-[spin_10s_linear_infinite]'}`}>
                            <div className="absolute inset-0 rounded-full border border-green-500/30"></div>
                            <div className="absolute inset-4 rounded-full border border-green-500/20 border-dashed"></div>
                            <div className={`w-2 h-2 bg-green-500 rounded-full absolute top-2 left-1/2 -translate-x-1/2 ${remixSettings.autoKeyDetect ? 'shadow-[0_0_10px_#0f0]' : ''}`}></div>
                            <RotateCw className={`w-8 h-8 text-neutral-800 ${isAnalyzingRemix ? 'text-green-500 animate-spin' : ''}`} />
                        </div>

                        <div className="mt-4 text-center">
                           {isAnalyzingRemix ? (
                               <div className="text-xs font-mono text-green-500 animate-pulse">DETECTING...</div>
                           ) : remixFile ? (
                               <>
                                 <div className="text-2xl font-bold text-white font-mono">F# Maj</div>
                                 <div className="text-[9px] text-green-500 font-mono uppercase tracking-widest">Synced to Track</div>
                               </>
                           ) : (
                               <>
                                 <div className="text-2xl font-bold text-neutral-700 font-mono">--</div>
                                 <div className="text-[9px] text-neutral-600 font-mono uppercase tracking-widest">Waiting for Input</div>
                               </>
                           )}
                        </div>
                    </div>
                 </div>
             </div>
          )}

          {/* UNLOCK OVERLAY (Only for FREE Users) */}
          {userTier === 'free' && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center">
                 {/* Gradient Glow Behind */}
                 <div className="absolute w-3/4 h-1/2 bg-red-500/10 blur-3xl rounded-full pointer-events-none"></div>
                 
                 <div className="relative bg-black/80 backdrop-blur-sm border border-neutral-800 p-6 md:p-8 shadow-2xl max-w-sm mx-auto transform transition-transform hover:scale-105">
                    <div className="flex flex-col items-center gap-3 mb-4">
                       <div className="w-10 h-10 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center shadow-[0_0_15px_rgba(255,0,0,0.2)]">
                          <Lock className="w-4 h-4 text-white" />
                       </div>
                       <h3 className="text-lg font-bold text-white uppercase tracking-wider">Studio Version Locked</h3>
                       <p className="text-[10px] font-mono text-neutral-400 leading-relaxed">
                          Advanced parameters including Lyrics, Stems, and Auto-Remix are reserved for Pro users.
                       </p>
                    </div>
                    
                    <button 
                       type="button"
                       onClick={onUpgrade}
                       className="w-full py-3 bg-white text-black text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2"
                    >
                       <span>Try Premium/Pro</span>
                       <ArrowRight className="w-3 h-3" />
                    </button>
                 </div>
              </div>
          )}
        </div>
        
        {/* HIGHLIGHT: DEMO READY CTA (Visible only for FREE users) */}
        {userTier === 'free' && (
        <div className="flex justify-center py-4">
            <div className="relative group cursor-default max-w-2xl w-full">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-green-900 to-green-800 rounded blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
                <div className="relative flex items-center justify-center gap-4 px-8 py-5 bg-black border border-green-900/50 shadow-[0_0_30px_-10px_rgba(0,255,0,0.1)]">
                    <Zap className="w-4 h-4 text-green-500 fill-current animate-[pulse_2s_ease-in-out_infinite]" />
                    <div className="text-center">
                         <h3 className="text-sm font-bold text-green-400 uppercase tracking-[0.2em] mb-1">Try Demo / Test Generate Audio Now</h3>
                         <p className="text-[9px] font-mono text-green-600/60 uppercase tracking-wider">
                            System Resources Available // Free Mode
                         </p>
                    </div>
                </div>
            </div>
        </div>
        )}

        {/* Preset Selection */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <label className="font-mono text-xs text-neutral-500 uppercase tracking-widest">01 // Select Genre Preset</label>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-0 border border-neutral-800 bg-neutral-900/50">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPreset(p.id)}
                className={`relative group flex flex-col items-start justify-between p-6 h-32 border border-neutral-800/50 transition-all duration-200 ${
                  selectedPreset === p.id
                    ? 'bg-white text-black z-10 scale-[1.02] shadow-2xl'
                    : 'bg-transparent text-neutral-400 hover:bg-neutral-900 hover:text-white'
                }`}
              >
                <div className="flex w-full justify-between items-start">
                   <span className={`text-xs font-mono uppercase tracking-wider ${selectedPreset === p.id ? 'text-neutral-500' : 'text-neutral-600'}`}>
                    {p.id.substring(0,3).toUpperCase()}
                   </span>
                   {selectedPreset === p.id && <Activity className="w-4 h-4 text-black" />}
                </div>
                
                <div>
                  <span className="block text-lg font-bold leading-none mb-1">{p.name}</span>
                  <span className={`text-[10px] font-mono block ${selectedPreset === p.id ? 'text-neutral-600' : 'text-neutral-600'}`}>
                    {p.desc.split(',')[0]}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Topic Input */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                <label htmlFor="topic" className="font-mono text-xs text-neutral-500 uppercase tracking-widest">02 // Input Prompt</label>
              </div>
              <div className="relative group">
                <input
                  id="topic"
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Describe the song topic..."
                  className="w-full bg-neutral-900/50 border border-neutral-800 rounded-none py-4 pl-4 pr-10 text-white placeholder-neutral-600 focus:outline-none focus:border-white focus:bg-black transition-all font-manrope"
                  required
                  autoComplete="off"
                />
                <Disc className="absolute right-4 top-4 w-5 h-5 text-neutral-700 group-focus-within:text-white transition-colors" />
              </div>
            </div>

            {/* Mood Input */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                <label htmlFor="mood" className="font-mono text-xs text-neutral-500 uppercase tracking-widest">03 // Atmosphere</label>
              </div>
              <div className="relative group">
                <input
                  id="mood"
                  type="text"
                  value={mood}
                  onChange={(e) => setMood(e.target.value)}
                  placeholder="E.g. Energetic, Dark, Hypnotic..."
                  className="w-full bg-neutral-900/50 border border-neutral-800 rounded-none py-4 pl-4 pr-10 text-white placeholder-neutral-600 focus:outline-none focus:border-white focus:bg-black transition-all font-manrope"
                  autoComplete="off"
                />
                <Sliders className="absolute right-4 top-4 w-5 h-5 text-neutral-700 group-focus-within:text-white transition-colors" />
              </div>
            </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting || !topic}
            className={`w-full py-5 font-bold text-sm tracking-[0.2em] uppercase flex items-center justify-center gap-4 transition-all border border-transparent ${
              isSubmitting || !topic
                ? 'bg-neutral-900 text-neutral-600 cursor-not-allowed border-neutral-800'
                : 'bg-white text-black hover:bg-neutral-200 hover:scale-[0.99] shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)]'
            }`}
          >
            {isSubmitting ? (
              <>
                <Visualizer status="processing" progress={50} className="h-3" />
                <span className="animate-pulse">Processing Sequence...</span>
                <Visualizer status="processing" progress={50} className="h-3 rotate-180" />
              </>
            ) : (
              <>
                <span>Initiate Synthesis</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default GeneratorForm;

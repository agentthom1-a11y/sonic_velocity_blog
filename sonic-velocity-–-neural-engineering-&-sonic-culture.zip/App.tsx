
import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import GeneratorForm from './components/GeneratorForm';
import JobList from './components/JobList';
import Landing from './components/Landing';
import Pricing from './components/Pricing';
import Showcase from './components/Showcase';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { Terms, Privacy, SystemStatus } from './components/InfoPages';
import { Merch, About, Blog, Career } from './components/CompanyPages';
import { AIProducerBot } from './components/AIProducerBot';
import Preloader from './components/Preloader';
import { JobData, PresetType, ViewType, UserTier, MixingSettings, StemSettings, RemixSettings, Project } from './types';
import { generateTrackAPI, generateTrackMock, checkJobStatusAPI, checkJobStatusMock } from './services/api';
import { Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// TOGGLE THIS FOR DEMO MODE
const IS_DEMO_MODE = true; 

// MOCK PROJECTS FOR LOGGED IN USERS
const MOCK_PROJECTS: Project[] = [
  {
    id: 'PROJ_001',
    name: 'Project Alpha (Koplo V2)',
    lastModified: '2024-03-10',
    data: {
      preset: 'koplo',
      topic: 'Malam Minggu Kelabu',
      mood: 'Sad but dancing',
      mixingSettings: {
        bass: 8, mid: -2, treble: 4, compression: true, stereoWidth: 100, reverb: 20, delay: 0, distortion: 10
      },
      activeModules: { lyrics: false, advanced: true, cover: false, remix: false }
    }
  },
  {
    id: 'PROJ_002',
    name: 'Jedag Jedug Viral 2024',
    lastModified: '2024-03-12',
    data: {
      preset: 'edm',
      topic: 'Party Jakarta Selatan',
      mood: 'Hype, High Energy',
      activeModules: { lyrics: true, advanced: false, cover: false, remix: false },
      lyrics: "Angkat tangan ke atas\nKita goyang sampai pagi"
    }
  },
  {
    id: 'PROJ_003',
    name: 'Breakbeat Kota',
    lastModified: '2024-03-15',
    data: {
      preset: 'breakbeat',
      topic: 'Racing Mode',
      mood: 'Aggressive, Fast',
      activeModules: { lyrics: false, advanced: true, cover: false, remix: true },
      remixSettings: {
         targetBpm: 180,
         mixStyle: 'mashup',
         autoKeyDetect: true
      }
    }
  }
];

function App() {
  // State
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<ViewType>('landing');
  const [jobs, setJobs] = useState<JobData[]>([
    {
       jobId: "JOB_HD_772",
       topic: "Bass Gendang Mantap",
       preset: "koplo",
       mood: "Vibrant",
       status: "done",
       createdAt: Date.now() - 3600000 * 2,
       url: "#"
    },
    {
       jobId: "JOB_HD_771",
       topic: "Jedag Jedug TikTok",
       preset: "edm",
       mood: "High Energy",
       status: "done",
       createdAt: Date.now() - 3600000 * 5,
       url: "#"
    },
    {
       jobId: "JOB_HD_770",
       topic: "Slow Reverb Melancholy",
       preset: "breakbeat",
       mood: "Sad",
       status: "done",
       createdAt: Date.now() - 3600000 * 24,
       url: "#"
    },
    {
       jobId: "JOB_HD_769",
       topic: "Funkot Angkot Vibe",
       preset: "funkot",
       mood: "Funky",
       status: "done",
       createdAt: Date.now() - 3600000 * 48,
       url: "#"
    },
    {
       jobId: "JOB_HD_768",
       topic: "Koplo Remix Jaran Goyang",
       preset: "koplo",
       mood: "Aggressive",
       status: "error",
       error: "Connection timeout",
       createdAt: Date.now() - 3600000 * 72
    },
    {
       jobId: "JOB_HD_767",
       topic: "Night Mood Chill",
       preset: "breakbeat",
       mood: "Chill",
       status: "done",
       createdAt: Date.now() - 3600000 * 96,
       url: "#"
    }
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [simulationMode, setSimulationMode] = useState(IS_DEMO_MODE);
  const [showStudioLock, setShowStudioLock] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [userTier, setUserTier] = useState<UserTier>('free');
  const [selectedBlogId, setSelectedBlogId] = useState<string | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [blogFilter, setBlogFilter] = useState<{ category?: string; tag?: string }>({});

  // Theme Effect
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light-mode');
    } else {
      document.documentElement.classList.remove('light-mode');
    }
  }, [theme]);

  // Ref to keep track of polling intervals
  const pollingRef = useRef<{[key: string]: number}>({});

  const handleCreateJob = async (
    preset: PresetType, 
    topic: string, 
    mood: string, 
    lyrics?: string, 
    voiceModel?: string,
    mixingSettings?: MixingSettings,
    stemSettings?: StemSettings,
    remixSettings?: RemixSettings
  ) => {
    setIsSubmitting(true);
    try {
      const apiCall = simulationMode ? generateTrackMock : generateTrackAPI;
      const response = await apiCall(preset, topic, mood, 60, lyrics, voiceModel, mixingSettings, stemSettings, remixSettings);

      const newJob: JobData = {
        jobId: response.jobId,
        preset,
        topic,
        mood,
        lyrics,
        voiceModel,
        mixingSettings,
        stemSettings,
        remixSettings,
        status: 'queued',
        createdAt: Date.now(),
      };

      setJobs(prev => [newJob, ...prev]);
      startPolling(newJob.jobId);

    } catch (error: any) {
      alert(`Error: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const startPolling = (jobId: string) => {
    const startTime = Date.now();

    const poll = async () => {
      try {
        const checkCall = simulationMode ? checkJobStatusMock : checkJobStatusAPI;
        
        // Pass elapsed seconds for mock logic
        const elapsed = (Date.now() - startTime) / 1000;
        const statusData = await checkCall(jobId, elapsed);

        setJobs(currentJobs => 
          currentJobs.map(job => {
            if (job.jobId !== jobId) return job;
            return { ...job, ...statusData };
          })
        );

        if (statusData.status === 'done' || statusData.status === 'error') {
          clearInterval(pollingRef.current[jobId]);
          delete pollingRef.current[jobId];
        }

      } catch (err) {
        console.error("Polling error", err);
      }
    };

    // Poll every 2 seconds
    pollingRef.current[jobId] = window.setInterval(poll, 2000);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      Object.values(pollingRef.current).forEach(clearInterval);
    };
  }, []);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const handleLoginSuccess = (tier: UserTier) => {
    setUserTier(tier);
    setIsLoggedIn(true);
    setCurrentView('dashboard');
  };

  const handleSignOut = () => {
    setIsLoggedIn(false);
    setUserTier('free');
    setCurrentView('landing');
  };

  return (
    <div className="min-h-screen relative flex flex-col">
      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="preloader"
            exit={{ opacity: 0, scale: 0.9, filter: 'blur(10px)' }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          >
            <Preloader onComplete={() => setIsLoading(false)} />
          </motion.div>
        ) : (
          <motion.div 
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
            className="flex-1 flex flex-col"
          >
            {/* Background Effects */}
            <div className="fixed inset-0 z-[-1] bg-grid opacity-[0.15] pointer-events-none"></div>
            <div className="fixed inset-0 z-[-1] bg-gradient-to-b from-neutral-900/0 to-black pointer-events-none"></div>

            <Header currentView={currentView} onNavigate={setCurrentView} isLoggedIn={isLoggedIn} />
            
            <main className="flex-1 flex flex-col">
              {currentView === 'landing' ? (
                <Landing 
                  onNavigate={setCurrentView} 
                  onSelectPost={setSelectedBlogId} 
                  onFilterBlog={(filter) => {
                    setBlogFilter(filter);
                    setSelectedBlogId(null);
                    setCurrentView('blog');
                  }}
                />
              ) : currentView === 'pricing' ? (
                <Pricing />
              ) : currentView === 'showcase' ? (
                <Showcase onStart={() => setCurrentView('studio')} />
              ) : currentView === 'login' ? (
                <Login onNavigate={setCurrentView} onLoginSuccess={handleLoginSuccess} />
              ) : currentView === 'dashboard' ? (
                <Dashboard 
                  onNavigate={setCurrentView} 
                  theme={theme}
                  onToggleTheme={toggleTheme}
                  userTier={userTier}
                  onSignOut={handleSignOut}
                  jobs={jobs}
                />
              ) : currentView === 'terms' ? (
                <Terms onBack={() => setCurrentView('landing')} />
              ) : currentView === 'privacy' ? (
                <Privacy onBack={() => setCurrentView('landing')} />
              ) : currentView === 'status' ? (
                <SystemStatus onBack={() => setCurrentView('landing')} />
              ) : currentView === 'merch' ? (
                <Merch onBack={() => setCurrentView('landing')} />
              ) : currentView === 'about' ? (
                <About onBack={() => setCurrentView('landing')} />
              ) : currentView === 'blog' ? (
                <Blog 
                  onBack={() => {
                    setSelectedBlogId(null);
                    setBlogFilter({});
                    setCurrentView('landing');
                  }} 
                  selectedId={selectedBlogId}
                  onSelect={setSelectedBlogId}
                  initialFilter={blogFilter}
                  onClearFilter={() => setBlogFilter({})}
                />
              ) : currentView === 'career' ? (
                <Career onBack={() => setCurrentView('landing')} />
              ) : (
                <div className="max-w-5xl mx-auto w-full px-6 pt-32 pb-20 animate-[fadeIn_0.5s_ease-out]">
                  {/* Studio Header */}
                  <div className="mb-12 border-b border-neutral-800 pb-8 flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                          <h2 className="text-3xl font-bold text-white tracking-tighter uppercase">
                            Synthesis Studio
                          </h2>
                          {userTier === 'free' ? (
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-500 rounded-sm">
                              <Lock className="w-3 h-3" />
                              <span className="text-[9px] font-bold uppercase tracking-widest">Studio Version Locked</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-green-900/20 border border-green-900/50 text-green-500 rounded-sm">
                              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                              <span className="text-[9px] font-bold uppercase tracking-widest">Studio Version // Unlocked</span>
                            </div>
                          )}
                      </div>
                      <p className="text-neutral-500 font-mono text-xs uppercase tracking-wider">
                        Configure parameters and initiate generation sequence
                      </p>
                    </div>

                    {/* Studio Mode Toggle (Locked for Free) */}
                    <div className="relative">
                      <button 
                        onClick={() => userTier === 'free' && setShowStudioLock(!showStudioLock)}
                        className={`flex items-center gap-3 border p-1 pr-4 rounded-sm transition-colors focus:outline-none ${
                            userTier !== 'free' 
                            ? 'border-green-900/50 bg-green-900/10 cursor-default' 
                            : 'border-neutral-800 bg-neutral-900/50 hover:bg-neutral-900 cursor-pointer'
                        }`}
                      >
                        <div className={`w-8 h-4 relative ${userTier !== 'free' ? 'bg-green-900/50' : 'bg-neutral-800'}`}>
                          <span className={`absolute top-0.5 w-3 h-3 left-0.5 transition-all ${
                              userTier !== 'free' ? 'bg-green-400 translate-x-4 shadow-[0_0_8px_rgba(0,255,0,0.5)]' : 'bg-neutral-600'
                          }`} />
                        </div>
                        <span className={`text-[9px] font-mono uppercase tracking-wider ${userTier !== 'free' ? 'text-green-400' : 'text-neutral-400'}`}>
                          {userTier !== 'free' ? 'Studio_Mode_Active' : 'Studio_Mode'}
                        </span>
                      </button>

                      {/* Locked Popover */}
                      {showStudioLock && userTier === 'free' && (
                        <div className="absolute right-0 top-full mt-2 w-72 bg-neutral-950 border border-red-900/30 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.8)] z-50 p-5 animate-[fadeIn_0.2s_ease-out]">
                            <div className="flex items-center gap-2 mb-3 text-red-500">
                              <div className="p-1 bg-red-950/50 rounded-sm">
                                  <Lock className="w-3 h-3" />
                              </div>
                              <span className="text-[10px] font-bold uppercase tracking-widest">Studio Version Locked</span>
                            </div>
                            <p className="text-[11px] text-neutral-400 mb-5 font-mono leading-relaxed border-t border-neutral-900 pt-3">
                              Advanced parameters including Lyrics, Stems, and Auto-Remix are reserved for Pro users.
                            </p>
                            <button 
                              onClick={() => setCurrentView('pricing')}
                              className="w-full py-2.5 bg-white text-black text-[10px] font-bold uppercase tracking-[0.15em] hover:bg-neutral-200 transition-colors"
                            >
                              Try Premium/Pro
                            </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <GeneratorForm 
                    onSubmit={handleCreateJob} 
                    isSubmitting={isSubmitting}
                    onUpgrade={() => setCurrentView('pricing')}
                    userTier={userTier}
                    projects={userTier !== 'free' ? MOCK_PROJECTS : []}
                  />
                  <JobList jobs={jobs} />
                </div>
              )}
            </main>

            {/* Global AI Assistant - Only for Pro/Agency */}
            {(userTier === 'pro' || userTier === 'agency') && <AIProducerBot />}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
